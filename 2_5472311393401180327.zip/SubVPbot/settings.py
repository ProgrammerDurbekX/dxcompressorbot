
token = "1190040835:AAEyW0vI2YgxahOsDl4HbmrNNwv_WK6LDE8"

admins = [777939924, 682967056] #админы бота через запятую

LITTLE_SUBCOIN_TO_GET_SUBS = 5 #минимум сабкоинов для раскрутки канала

REF_BONUS = 2 #реферальный бонус (сабкоины)

FINE_FOR_UNSUBSCRIBING = -5 #Число должно быть отрицательным и целым

SUBSCRIPTION_TERM = 7 #Какое время юзер должен оьязательно быть подписан на канал?

LINK_TO_INTRODUCTION_AND_RULES = 'https://graph.org/Vvedenie-v-bota-a-takzhe-pravila-05-11' #ссылка на правила и инструкцию

LINK_TO_CHAT_OF_BOT = '@hacker_kg' #ссылка на чат
